# Jujutsu Kaisen

A Pen created on CodePen.io. Original URL: [https://codepen.io/RIOLEXUS-BATSYABA/pen/XWvwvBY](https://codepen.io/RIOLEXUS-BATSYABA/pen/XWvwvBY).

This is a fan made Jujutsu Kaisen work.